package testcase.Railway;

import pageObjects.Railway.GeneralPage;
import pageObjects.Railway.HomePage;
import pageObjects.Railway.LoginPage;
import pageObjects.Railway.RegisterPage;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.JavascriptExecutor;


import Common.Utilities;
import Common.Constant;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
public class RegisterTest {
    @BeforeMethod
    public void beforeMethod() {
        System.out.println("Pre-condition");
        Constant.WEBDRIVER = new ChromeDriver();
        Constant.WEBDRIVER.manage().window().maximize();
    }

    //    @AfterMethod
//    public void afterMethod() {
//        System.out.println("Post-condition");
//        Constant.WEBDRIVER.quit();
//    }
    @Test
    public void TC07()throws InterruptedException{
        System.out.println("User can create new account");
        HomePage homePage = new HomePage();
        homePage.open();
        RegisterPage registerPage = homePage.gotoRegister();
        String actualMsg = registerPage.register(Constant.NEW_ACCOUNT_EMAIL, Constant.NEW_ACCOUNT_PASSWORD, Constant.NEW_ACCOUNT_CONFIRM_PASSWORD, Constant.NEW_ACCOUNT_ID).getWelcomeMessage();
        String expectedMsg = "Thank you for registering your account";
        Assert.assertEquals(actualMsg, expectedMsg, "");
        Thread.sleep(10000);

    }
    @Test
    public void TC10() throws InterruptedException{
        System.out.println("User can't create account with 'Confirm password' is not the same with 'Password'");
        HomePage homePage = new HomePage();
        homePage.open();
        RegisterPage registerPage = homePage.gotoRegister();
        registerPage.getTxtEmail().sendKeys("nthanhhien227@gmail.com");
        registerPage.getTxtPassword().sendKeys("12345678");
        registerPage.getTxtConfirmPassword().sendKeys("123456789");
        registerPage.getTxtPid().sendKeys("1234567890");
        registerPage.getBtnRegister().submit();
        String actualMsg = registerPage.getLblRegisterErrorMsg().getText();
        String expectedMsg = "There're errors in the form. Please correct the errors and try again.";
        Assert.assertEquals(actualMsg, expectedMsg, "Success message is not displayed as expected");
        Thread.sleep(20000);
    }

}