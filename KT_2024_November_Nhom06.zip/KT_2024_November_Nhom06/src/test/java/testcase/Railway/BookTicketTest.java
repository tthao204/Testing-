package testcase.Railway;
import java.time.Duration;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageObjects.Railway.*;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import Common.Utilities;
import Common.Constant;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;



public class BookTicketTest {
    @BeforeMethod
    public void beforeMethod() {
        System.out.println("Pre-condition");
        Constant.WEBDRIVER = new ChromeDriver();
        Constant.WEBDRIVER.manage().window().maximize();
    }
//        @AfterMethod
//    public void afterMethod(){
//        System.out.println("Post-condition");
//        Constant.WEBDRIVER.quit();
//    }

    @Test
    public void TC14() {
        System.out.println("User can book 1 ticket at a time");
        HomePage homePage = new HomePage();
        homePage.open();
        LoginPage loginPage = homePage.gotoLoginPage();
        loginPage.getTxtUsername().sendKeys("hienne22@gmail.com");
        loginPage.getTxtPassword().sendKeys("123456789");
        loginPage.getBtnLogin().submit();
        BookTicketPage bookTicketPage = homePage.clickBookTicketTab();
        bookTicketPage.selectDepartDate(5);
        bookTicketPage.selectDepartFrom("Quảng Ngãi");
        bookTicketPage.selectArriveAt("Đà Nẵng");

        bookTicketPage.selectSeatType("Soft bed with air conditioner");
        bookTicketPage.selectTicketAmount("1");

        bookTicketPage.clickBookTicketButton();
        Assert.assertTrue(bookTicketPage.isTicketBookedSuccessfullyDisplayed(), "Ticket booked successfully message is not displayed");

        boolean ticketDetailsMatch = bookTicketPage.verifyTicketDetails("Quảng Ngãi", "Sài Gòn", "Soft bed with air conditioner", bookTicketPage.getDepartDate(), "1");
        System.out.println("Depart Station: " + bookTicketPage.getDepartStation());
        System.out.println("Arrive Station: " + bookTicketPage.getArriveStation());
        System.out.println("Seat Type: " + bookTicketPage.getSeatType());
        System.out.println("Depart Date: " + bookTicketPage.getDepartDate());
        System.out.println("Amount: " + bookTicketPage.getAmount());
        Assert.assertTrue(ticketDetailsMatch, "Ticket details do not match.");
    }

    @Test
    public void TC15() {
        System.out.println("User can open 'Book ticket' page by clicking on 'Book ticket' link in 'Train timetable' page");

        HomePage homePage = new HomePage();
        homePage.open();

        LoginPage loginPage = homePage.gotoLoginPage();
        loginPage.getTxtUsername().sendKeys("hienne22@gmail.com");
        loginPage.getTxtPassword().sendKeys("123456789");
        loginPage.getBtnLogin().submit();

        TimeTablePage trainTimetablePage = homePage.gotoTrainTimetablePage();
        trainTimetablePage.SelectbookTicketClick();

        WebDriverWait wait = new WebDriverWait(Constant.WEBDRIVER, Duration.ofSeconds(10));
        WebElement departFromElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='content']/div[1]/form/fieldset/ol/li[2]/select")));
        WebElement arriveStationElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id='ArriveStation']/select")));

        Select departFrom = new Select(departFromElement);
        Select arriveStation = new Select(arriveStationElement);

        // In ra các lựa chọn để kiểm tra
        List<WebElement> departOptions = departFrom.getOptions();
        for (WebElement option : departOptions) {
            System.out.println(option.getText());
        }

        ArrayList<String> compare = new ArrayList<>();
        compare.add(departFrom.getFirstSelectedOption().getText());
        compare.add(arriveStation.getFirstSelectedOption().getText());

    }
    @Test
    public void TC16()
    {
        System.out.println("TC16 -  User can cancel a ticket");
        HomePage homePage = new HomePage();
        homePage.open();
        LoginPage loginPage = homePage.gotoLoginPage();
        loginPage.getTxtUsername().sendKeys("hienne22@gmail.com");
        loginPage.getTxtPassword().sendKeys("123456789");
        loginPage.getBtnLogin().submit();
        BookTicketPage bookTicketPage = homePage.gotoBookTicketPage();
        LocalDate currentDate = LocalDate.now().plusDays(4);
        String departDate = currentDate.format(DateTimeFormatter.ofPattern("d"));
        bookTicketPage.selectDepartDate(Integer.parseInt(departDate));
        bookTicketPage.selectDepartFrom("Quảng Ngãi");
        bookTicketPage.selectArriveAt("Huế");
        bookTicketPage.selectSeatType("Hard seat");
        bookTicketPage.selectTicketAmount("1");
        bookTicketPage.clickBookTicketButton();
        String url = Constant.WEBDRIVER.getCurrentUrl();
        String[] urls = url.split("id=");
        String delete= urls[1];
        String xp ="//input[@onclick='DeleteTicket("+delete+");']";
        MyTicketPage ticket = homePage.gotoMyTicketPage();
        JavascriptExecutor js = (JavascriptExecutor) Constant.WEBDRIVER;
        js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
        ticket.clickCancelButton(xp);
        Constant.WEBDRIVER.switchTo().alert().accept();
        boolean isTicketDisplayed = true;
        try {
            WebElement CancelButtonElement = Constant.WEBDRIVER.findElement(By.xpath(xp));
            isTicketDisplayed = CancelButtonElement.isDisplayed();
        }
        catch (NoSuchElementException e) {
            isTicketDisplayed = false;
        }
        Assert.assertFalse(isTicketDisplayed, "The ticket does not disappear");
    }
}




