package Common;
import org.openqa.selenium.WebDriver;
public class Constant {
    public static WebDriver WEBDRIVER;
    public static final String RAILWAY_URL = "http://railwayb1.somee.com/Page/HomePage.cshtml";
    public static final String USERNAME = "hienhien22@gmail.com";
    public static final String PASSWORD = "123456789";
    public static  final String EMAIL = "hienhien22@gmail.com";
    public static final String CONFIRMPASSWORD ="123456789";
    public static final String ID ="1234567890";

    public static final String NEW_ACCOUNT_EMAIL = "hiennguyen2@gmail.com";  // New account email
    public static final String NEW_ACCOUNT_PASSWORD = "1234567890";  // New account password
    public static final String NEW_ACCOUNT_CONFIRM_PASSWORD = "1234567890";  // New account confirm password
    public static final String NEW_ACCOUNT_ID = "9876543210";  // New account ID

}

